var app = angular.module('trainApp', ['ngRoute','ngMaterial','ngMessages']);

//configure our routes
app.config(function($routeProvider){
	$routeProvider

	//route for the home page
	.when('/', {
			templateUrl : 'pages/pnr-status.html',
			controller  : 'mainController',
			activetab   : 'pnrStatus'
	})

	//route for the train availability page
	.when('/train-availability', {
			templateUrl : 'pages/train-availability.html',
			controller  : 'trainAvailController',
			activetab: 'trainAvailability'
	})

	//route for the train schedule page
	.when('/live-stations', {
			templateUrl : 'pages/live-stations.html',
			controller  : 'liveStationController',
			activetab: 'liveStations'
	})


	//route for the live trains page
	.when('/live-trains', {
			templateUrl : 'pages/live-trains.html',
			controller  : 'trainLiveController',
			activetab: 'liveTrains'
	})


	//route for the train schedule page
	.when('/seat-availablity', {
			templateUrl : 'pages/seat-availability.html',
			controller  : 'seatAvailablityController'
	})

});

/*function for routing*/
function widgetController($scope, $route) {
    $scope.$route = $route;
}


/*global function for train route*/
function getTrainRoute($scope,$http,obj){
/*var trainBox = angular.element( document.querySelector( '.train-route-box' ) );
var body = angular.element( document.querySelector( 'body' ) );
	 console.log(obj);
		 var trainNo = obj.target.attributes.trainNo.value;
		 console.log(trainNo);
		//alert(obj.target.attributes.trainNo.value);
		$http.get("http://api.railwayapi.com/route/train/"+trainNo+"/apikey/ybmgk2294/").then(function(response){$scope.routes = response.data;}).then(function(){
			console.log($scope.routes);
		});

		
		body.addClass('popup-open');
		$scope.hideLoader = false;
		trainBox.addClass('active');*/
}


/*controllers start*/

// create the controller and inject Angular's $scope
//PNR Enquiry Controller
app.controller('mainController', function($scope,$http,$route){
	widgetController($scope, $route);
	$scope.hidePnrResult = true;
	$scope.hideErrorBox = true;
	$scope.hideLoader = true;
	$scope.getPnr = function() {
		console.log($scope.pnrNo);
	$scope.hidePnrResult = true;
	$scope.hideErrorBox = true;
	$scope.hideLoader = false;
	$http.get("http://api.railwayapi.com/pnr_status/pnr/"+$scope.pnrNo+"/apikey/ybmgk2294/").then(function(response) {$scope.details = response.data;}).then(function(){
		//console.log($scope.details.error);
		$scope.hideLoader = true;
		if($scope.details.error){
			$scope.hideErrorBox = false;
			console.log($scope.details.error);	
		}
		else{
			$scope.hidePnrResult = false;
		}
	});

	/*$http({
		url:'http://api.railwayapi.com/pnr_status/pnr/'+$scope.pnrNo+'/apikey/ybmgk2294/',
		method: 'get',
		data: {user_id: $scope.pnrNo}
	}).then(function(response) {$scope.details = response.data;});*/
		//$scope.hidePnrResult = false;
	
	//console.log($scope.pnrNo);
	};
});	

//Train Availability Controller
app.controller('trainAvailController', function($scope, $http,$route){
	widgetController($scope, $route);
	$scope.hideTrainAvailResult = true;	
	$scope.hideErrorBox = true;
	$scope.hideLoader = true;

	var fromStation ='',ToStation ='',date ='', month = '', year = '';

	$scope.getTrains = function(){
		date  = $scope.myDate.getDate();
		month = $scope.myDate.getMonth()+1;
		year  = $scope.myDate.getFullYear();
		if(date < 10){
		date = '0'+date;	
		}
		if (month < 10) {
		month = '0'+month;
		};
		//console.log(year);
		$scope.hideTrainAvailResult = true;	
		$scope.hideErrorBox = true;
		$scope.hideLoader = false;
		fromStation = $scope.fromStation;
		ToStation   = $scope.ToStation;
		//date        = $scope.date;	
		$http.get("http://api.railwayapi.com/between/source/"+$scope.fromStation+"/dest/"+$scope.ToStation+"/date/"+date+'-'+month+"/apikey/ybmgk2294/").then(function(response){$scope.trains = response.data;}).then(function(){
				$scope.hideLoader = true;
				if($scope.trains.response_code == 204){
					$scope.hideErrorBox = false;
					console.log($scope.trains.error);	
				}
				else{
					$scope.hideTrainAvailResult = false;
					console.log($scope.trains);
				}
			});
	};

	var trainBox = angular.element( document.querySelector( '.train-route-box' ) );
	var body = angular.element( document.querySelector( 'body' ) );
	/*Module for show train route popup*/
	

	$scope.getTrainRoute = function(obj){
	 	console.log(obj);
		var trainNo = obj.target.attributes.trainNo.value;
		console.log(trainNo);
		//alert(obj.target.attributes.trainNo.value);
		$http.get("http://api.railwayapi.com/route/train/"+trainNo+"/apikey/ybmgk2294/").then(function(response){$scope.routes = response.data;}).then(function(){
			console.log($scope.routes);
		});

		
		body.addClass('popup-open');
		$scope.hideLoader = false;
		trainBox.addClass('active'); 
	};

	/*module end for train route popup*/

	/*module for seat availability popup*/
	var seatAvailBox = angular.element(document.querySelector('.seat-availability-box'));

	$scope.getSeatAvail = function(obj){
		 var trainNo = obj.target.attributes.trainNo.value;
		 var classCode = obj.target.attributes.classCode.value;
		 /*console.log(trainNo);	
		 console.log(classCode);
		 console.log(fromStation);
		 console.log(ToStation);
		 console.log(date);	*/
		 $http.get("http://api.railwayapi.com/check_seat/train/"+trainNo+"/source/"+fromStation+"/dest/"+ToStation+"/date/"+date+'-'+month+'-'+year+"/class/"+classCode+"/quota/GN/apikey/ybmgk2294/").then(function(response){$scope.seats = response.data;}).then(function(){
		 		console.log($scope.seats);
		 });

		body.addClass('popup-open');
		$scope.hideLoader = false;
		seatAvailBox.addClass('active');
	};
	
	$scope.overlayClick = function(){
		trainBox.removeClass('active'); 
		seatAvailBox.removeClass('active');
		body.removeClass('popup-open');
		$scope.hideLoader = true; 
	};

	$scope.myDate = new Date();

  	$scope.minDate = new Date(
      $scope.myDate.getFullYear(),
      $scope.myDate.getMonth(),
      $scope.myDate.getDate());

  	$scope.maxDate = new Date(
      $scope.myDate.getFullYear(),
      $scope.myDate.getMonth() + 4,
      $scope.myDate.getDate());
});


//Live Station Controller
app.controller('liveStationController', function($scope,$http,$route){
	widgetController($scope, $route);
	$scope.hideResultBox = true;
	$scope.hideErrorBox = true;
	$scope.hideLoader = true;
	$scope.hideSuggestedResult = true;
	$scope.getLiveStation = function(){
		$scope.hideResultBox = true;
		$scope.hideErrorBox = true;
		$scope.hideLoader = false;
		$http.get("http://api.railwayapi.com/arrivals/station/"+$scope.stationCode+"/hours/2/apikey/ybmgk2294/").then(function(response){$scope.trains = response.data;}).then(function(){
				$scope.hideLoader = true;
				if($scope.trains.response_code == 200){
					$scope.hideResultBox = false;
					console.log($scope.trains);	
				}
				else{
					$scope.hideErrorBox = false;
				}
		});
	};

	var trainBox = angular.element( document.querySelector( '.train-route-box' ) );
	var body = angular.element( document.querySelector( 'body' ) );

	$scope.getTrainRoute = function(obj){
		console.log(obj);
		var trainNo = obj.target.attributes.trainNo.value;
		console.log(trainNo);
		//alert(obj.target.attributes.trainNo.value);
		$http.get("http://api.railwayapi.com/route/train/"+trainNo+"/apikey/ybmgk2294/").then(function(response){$scope.routes = response.data;}).then(function(){
			console.log($scope.routes);
		});

		
		body.addClass('popup-open');
		$scope.hideLoader = false;
		trainBox.addClass('active'); 
	};

	$scope.overlayClick = function(){
		body.removeClass('popup-open');
		$scope.hideLoader = true;
		trainBox.removeClass('active'); 
	};

	
	$scope.showStation = function(stationCode){
		if(stationCode.length >= 3)
		{
			//console.log(stationCode);
			$http.get("http://api.railwayapi.com/suggest_station/name/"+stationCode+"/apikey/ybmgk2294/").then(function(response){$scope.stations = response.data;}).then(function(){
				console.log($scope.stations);
			});
			$scope.hideSuggestedResult = false;
		}
	};
	var setStation = '';

	$scope.setStationCode = function(setStationCode){
		//setStation = setStationCode;
		//console.log('kuch to hua hai');
		//console.log(setStation);
		$scope.stationCode = setStationCode;
		$scope.hideSuggestedResult = true;
	};	
});


//Live Train Controller
app.controller('trainLiveController', function($scope, $http,$route){
	widgetController($scope, $route);
	$scope.hideResultBox = true;
	$scope.hideErrorBox = true;
	$scope.hideLoader = true;

	var date ='', month = '', year = '';
	$scope.getLiveTrain = function(){
		//console.log('function chala');
		date  = $scope.myDate.getDate();
		month = $scope.myDate.getMonth()+1;
		year  = $scope.myDate.getFullYear();

		if(date < 10){
		date = '0'+date;	
		}
		if (month < 10) {
		month = '0'+month;
		};
		console.log(year);
		console.log(month);
		console.log(date);
		$scope.hideResultBox = true;
		$scope.hideErrorBox = true;
		$scope.hideLoader = false;

		$http.get("http://api.railwayapi.com/live/train/"+$scope.trainCode+"/doj/"+year+month+date+"/apikey/ybmgk2294/").then(function(response){$scope.trainStatus = response.data}).then(function(){
			$scope.hideLoader = true;
			if($scope.trainStatus.response_code == 200){
				$scope.hideResultBox = false;
				console.log($scope.trainStatus);
			}
			else{
				$scope.hideErrorBox = false;
			}
		});
	};

	$scope.myDate = new Date();

  	$scope.minDate = new Date(
      $scope.myDate.getFullYear(),
      $scope.myDate.getMonth(),
      $scope.myDate.getDate() - 7);

  	$scope.maxDate = new Date(
      $scope.myDate.getFullYear(),
      $scope.myDate.getMonth(),
      $scope.myDate.getDate() + 1 );

});

//snjwd3391 Bkup apikey